﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Ben Michener
// 10/30/17
// Calculator
namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double valOne = 0;
        private double valTwo = 0;
        private double memory = 0;
        private String op;
        private String lastInput = "";

//Handles Solving
        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (op != null)
            {
                valTwo = Double.Parse(txtDisplay.Text);
                valOne = solve();
                txtDisplay.Text = valOne.ToString();
                op = null;
                lblDisplay.Text = "";
                lastInput = "Enter";
            }
            
        }
//Handles All Numbers
        private void btnZero_Click(object sender, EventArgs e)
        {
            if (lastInput.Equals("Enter"))
            {
                txtDisplay.Text = ActiveControl.Text;
            }
            else
            {
                if (txtDisplay.Text.Equals("0"))
                    txtDisplay.Text = ActiveControl.Text;
                else
                    txtDisplay.Text += (ActiveControl.Text);
            }
            lastInput = ActiveControl.Text;
        }
//Handles Decimals
        private void btnDecimal_Click(object sender, EventArgs e)
        {
            if(!txtDisplay.Text.Contains("."))
                txtDisplay.Text += ".";
            lastInput = ActiveControl.Text;
        }
//Handles All Operations
        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            if (op != null)
            {
                if (lastInput.Equals("+") || lastInput.Equals("-") || lastInput.Equals("x") || lastInput.Equals("/"))
                {
                    lblDisplay.Text = lblDisplay.Text.Substring(0, lblDisplay.Text.Length - 1) + ActiveControl.Text;
                    lastInput = ActiveControl.Text;
                }
                else
                {
                    btnEnter_Click(sender, e);

                    valOne = Double.Parse(txtDisplay.Text);
                    lblDisplay.Text = txtDisplay.Text + " " + ActiveControl.Text;
                    txtDisplay.Text = "0";
                    lastInput = ActiveControl.Text;
                }
                op = ActiveControl.Text;
            }
            else
            {
                valOne = Double.Parse(txtDisplay.Text);
                lblDisplay.Text = txtDisplay.Text;
                txtDisplay.Text = "0";

                op = (ActiveControl.Text);
                lblDisplay.Text += " " + ActiveControl.Text;
                lastInput = ActiveControl.Text;
            }
        }

// Everything else does what it says on the tin
        private void btnSquared_Click(object sender, EventArgs e)
        {
            valOne = Double.Parse(txtDisplay.Text);
            txtDisplay.Text = (valOne * valOne).ToString();
        }

        private double solve()
        {
            if (op.Equals("+"))
                return (valOne + valTwo);
            else if (op.Equals("-"))
                return (valOne - valTwo);
            else if (op.Equals("x"))
                return (valOne * valTwo);
            else if (op.Equals("/"))
                return (valOne / valTwo);
            else
                return 0;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "0";
            lblDisplay.Text = "";
            valOne = 0;
            valTwo = 0;
            op = null;
            lastInput = "";
        }

        private void btnBackSpace_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text.Length > 0)
                txtDisplay.Text = txtDisplay.Text.Substring(0, txtDisplay.Text.Length - 1);
            if (txtDisplay.Text.Length == 0)
                txtDisplay.Text = "0";
        }

        private void btnSignSwap_Click(object sender, EventArgs e)
        {
            valOne = Double.Parse(txtDisplay.Text);
            txtDisplay.Text = (valOne * -1).ToString();
        }

        private void btnPercent_Click(object sender, EventArgs e)
        {
            double temp = Double.Parse(txtDisplay.Text);
            txtDisplay.Text = ((temp / 100) * valOne).ToString();
        }

        private void btnSqrt_Click(object sender, EventArgs e)
        {
            valOne = Double.Parse(txtDisplay.Text);
            txtDisplay.Text = (Math.Sqrt(valOne)).ToString();
        }

        private void btnClearEntry_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "";
        }

        private void btnMemStore_Click(object sender, EventArgs e)
        {
            memory = Double.Parse(txtDisplay.Text);
        }

        private void btnMemRecall_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = memory.ToString();
        }

        private void btnMemClear_Click(object sender, EventArgs e)
        {
            memory = 0;
        }

        private void btnMemAdd_Click(object sender, EventArgs e)
        {
            valOne = Double.Parse(txtDisplay.Text);
            txtDisplay.Text = (valOne + memory).ToString();
        }

        private void btnRecip_Click(object sender, EventArgs e)
        {
            valOne = Double.Parse(txtDisplay.Text);
            txtDisplay.Text = (1 / valOne).ToString();
        }
    }
}
