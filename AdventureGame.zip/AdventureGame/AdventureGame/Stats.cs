﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureGame
{
    public class Stats
    {
        private double m_con;
        private double m_dex;
        private double m_skill;
        private double m_str;
        private string m_name;
        private int m_num;

        public String Name //Hero Name
        {
            get
            {
                return m_name;
            }

            set
            {
                m_name = value;
            }
        }

        public double Con //Handles health
        {
            get
            {
                return m_con;
            }

            set
            {
                m_con = value;
            }
        }

        public double Dex //Handles % chance to dodge
        {
            get
            {
                return m_dex;
            }

            set
            {
                m_dex = value;
            }
        }

        public double Str //Handles Damage
        {
            get
            {
                return m_str;
            }

            set
            {
                m_str = value;
            }
        }

        public double Skill //Handles % chance to hit
        {
            get
            {
                return m_skill;
            }

            set
            {
                m_skill = value;
            }
        }

        public int Num //Handles the number of enemies (in the case of a horde of enemies ex: goblins)
        {
            get
            {
                return m_num;
            }

            set
            {
                m_num = value;
            }
        }

        public Stats(string name, double constituation, double dexterity, double skill, double strength, int numbers) //Constructor
        {
            m_con = constituation;
            m_dex = dexterity;
            m_name = name;
            m_skill = skill;
            m_str = strength;
            m_num = numbers;
        }

        public void takeDamage(int damage)      //Take damage equal to x amount
        {
            m_con -= damage;
        }
    }
}
