﻿namespace AdventureGame
{
    partial class Map
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Map));
            this.picMap = new System.Windows.Forms.PictureBox();
            this.btnCheckInventory = new System.Windows.Forms.Button();
            this.btnContineAdventure = new System.Windows.Forms.Button();
            this.btnCheckParty = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCurrentTime = new System.Windows.Forms.TextBox();
            this.btnFirewood = new System.Windows.Forms.Button();
            this.btnFood = new System.Windows.Forms.Button();
            this.radPlains = new System.Windows.Forms.RadioButton();
            this.radForest = new System.Windows.Forms.RadioButton();
            this.radSwamp = new System.Windows.Forms.RadioButton();
            this.radMountains = new System.Windows.Forms.RadioButton();
            this.radFlameFields = new System.Windows.Forms.RadioButton();
            this.radFinish = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.picMap)).BeginInit();
            this.SuspendLayout();
            // 
            // picMap
            // 
            this.picMap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picMap.Image = ((System.Drawing.Image)(resources.GetObject("picMap.Image")));
            this.picMap.Location = new System.Drawing.Point(12, 12);
            this.picMap.Name = "picMap";
            this.picMap.Size = new System.Drawing.Size(418, 237);
            this.picMap.TabIndex = 0;
            this.picMap.TabStop = false;
            // 
            // btnCheckInventory
            // 
            this.btnCheckInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckInventory.Location = new System.Drawing.Point(436, 38);
            this.btnCheckInventory.Name = "btnCheckInventory";
            this.btnCheckInventory.Size = new System.Drawing.Size(129, 35);
            this.btnCheckInventory.TabIndex = 1;
            this.btnCheckInventory.Text = "Check Inventory";
            this.btnCheckInventory.UseVisualStyleBackColor = true;
            this.btnCheckInventory.Click += new System.EventHandler(this.btnCheckInventory_Click);
            // 
            // btnContineAdventure
            // 
            this.btnContineAdventure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContineAdventure.Location = new System.Drawing.Point(436, 208);
            this.btnContineAdventure.Name = "btnContineAdventure";
            this.btnContineAdventure.Size = new System.Drawing.Size(129, 41);
            this.btnContineAdventure.TabIndex = 2;
            this.btnContineAdventure.Text = "Continue Adventure";
            this.btnContineAdventure.UseVisualStyleBackColor = true;
            this.btnContineAdventure.Click += new System.EventHandler(this.btnContineAdventure_Click);
            // 
            // btnCheckParty
            // 
            this.btnCheckParty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckParty.Location = new System.Drawing.Point(436, 79);
            this.btnCheckParty.Name = "btnCheckParty";
            this.btnCheckParty.Size = new System.Drawing.Size(129, 35);
            this.btnCheckParty.TabIndex = 3;
            this.btnCheckParty.Text = "Check Party";
            this.btnCheckParty.UseVisualStyleBackColor = true;
            this.btnCheckParty.Click += new System.EventHandler(this.btnCheckParty_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(436, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Time:";
            // 
            // txtCurrentTime
            // 
            this.txtCurrentTime.Location = new System.Drawing.Point(484, 12);
            this.txtCurrentTime.Name = "txtCurrentTime";
            this.txtCurrentTime.ReadOnly = true;
            this.txtCurrentTime.Size = new System.Drawing.Size(81, 20);
            this.txtCurrentTime.TabIndex = 5;
            // 
            // btnFirewood
            // 
            this.btnFirewood.Location = new System.Drawing.Point(436, 120);
            this.btnFirewood.Name = "btnFirewood";
            this.btnFirewood.Size = new System.Drawing.Size(58, 40);
            this.btnFirewood.TabIndex = 6;
            this.btnFirewood.Text = "Look for Firewood";
            this.btnFirewood.UseVisualStyleBackColor = true;
            this.btnFirewood.Click += new System.EventHandler(this.btnFood_Click);
            // 
            // btnFood
            // 
            this.btnFood.Location = new System.Drawing.Point(500, 120);
            this.btnFood.Name = "btnFood";
            this.btnFood.Size = new System.Drawing.Size(65, 40);
            this.btnFood.TabIndex = 7;
            this.btnFood.Text = "Hunt for Food";
            this.btnFood.UseVisualStyleBackColor = true;
            this.btnFood.Click += new System.EventHandler(this.btnFirewood_Click);
            // 
            // radPlains
            // 
            this.radPlains.AutoSize = true;
            this.radPlains.BackColor = System.Drawing.SystemColors.ControlLight;
            this.radPlains.Checked = true;
            this.radPlains.Location = new System.Drawing.Point(37, 132);
            this.radPlains.Name = "radPlains";
            this.radPlains.Size = new System.Drawing.Size(53, 17);
            this.radPlains.TabIndex = 8;
            this.radPlains.TabStop = true;
            this.radPlains.Text = "Plains";
            this.radPlains.UseVisualStyleBackColor = false;
            this.radPlains.CheckedChanged += new System.EventHandler(this.radPlains_CheckedChanged);
            // 
            // radForest
            // 
            this.radForest.AutoSize = true;
            this.radForest.BackColor = System.Drawing.SystemColors.ControlLight;
            this.radForest.Location = new System.Drawing.Point(200, 115);
            this.radForest.Name = "radForest";
            this.radForest.Size = new System.Drawing.Size(54, 17);
            this.radForest.TabIndex = 9;
            this.radForest.Text = "Forest";
            this.radForest.UseVisualStyleBackColor = false;
            this.radForest.CheckedChanged += new System.EventHandler(this.radPlains_CheckedChanged);
            // 
            // radSwamp
            // 
            this.radSwamp.AutoSize = true;
            this.radSwamp.BackColor = System.Drawing.SystemColors.ControlLight;
            this.radSwamp.Location = new System.Drawing.Point(275, 190);
            this.radSwamp.Name = "radSwamp";
            this.radSwamp.Size = new System.Drawing.Size(60, 17);
            this.radSwamp.TabIndex = 10;
            this.radSwamp.Text = "Swamp";
            this.radSwamp.UseVisualStyleBackColor = false;
            this.radSwamp.CheckedChanged += new System.EventHandler(this.radPlains_CheckedChanged);
            // 
            // radMountains
            // 
            this.radMountains.AutoSize = true;
            this.radMountains.BackColor = System.Drawing.SystemColors.ControlLight;
            this.radMountains.Location = new System.Drawing.Point(263, 56);
            this.radMountains.Name = "radMountains";
            this.radMountains.Size = new System.Drawing.Size(74, 17);
            this.radMountains.TabIndex = 11;
            this.radMountains.Text = "Mountains";
            this.radMountains.UseVisualStyleBackColor = false;
            this.radMountains.CheckedChanged += new System.EventHandler(this.radPlains_CheckedChanged);
            // 
            // radFlameFields
            // 
            this.radFlameFields.AutoSize = true;
            this.radFlameFields.BackColor = System.Drawing.SystemColors.ControlLight;
            this.radFlameFields.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radFlameFields.Location = new System.Drawing.Point(347, 157);
            this.radFlameFields.Name = "radFlameFields";
            this.radFlameFields.Size = new System.Drawing.Size(76, 16);
            this.radFlameFields.TabIndex = 12;
            this.radFlameFields.Text = "Flame Fields";
            this.radFlameFields.UseVisualStyleBackColor = false;
            this.radFlameFields.CheckedChanged += new System.EventHandler(this.radPlains_CheckedChanged);
            // 
            // radFinish
            // 
            this.radFinish.AutoSize = true;
            this.radFinish.BackColor = System.Drawing.SystemColors.ControlLight;
            this.radFinish.Location = new System.Drawing.Point(347, 101);
            this.radFinish.Name = "radFinish";
            this.radFinish.Size = new System.Drawing.Size(52, 17);
            this.radFinish.TabIndex = 13;
            this.radFinish.Text = "Finish";
            this.radFinish.UseVisualStyleBackColor = false;
            this.radFinish.CheckedChanged += new System.EventHandler(this.radPlains_CheckedChanged);
            // 
            // Map
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 261);
            this.Controls.Add(this.radFinish);
            this.Controls.Add(this.radFlameFields);
            this.Controls.Add(this.radMountains);
            this.Controls.Add(this.radSwamp);
            this.Controls.Add(this.radForest);
            this.Controls.Add(this.radPlains);
            this.Controls.Add(this.btnFood);
            this.Controls.Add(this.btnFirewood);
            this.Controls.Add(this.txtCurrentTime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCheckParty);
            this.Controls.Add(this.btnContineAdventure);
            this.Controls.Add(this.btnCheckInventory);
            this.Controls.Add(this.picMap);
            this.Name = "Map";
            this.Text = "Map";
            this.Load += new System.EventHandler(this.Map_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picMap)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picMap;
        private System.Windows.Forms.Button btnCheckInventory;
        private System.Windows.Forms.Button btnContineAdventure;
        private System.Windows.Forms.Button btnCheckParty;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCurrentTime;
        private System.Windows.Forms.Button btnFirewood;
        private System.Windows.Forms.Button btnFood;
        private System.Windows.Forms.RadioButton radPlains;
        private System.Windows.Forms.RadioButton radForest;
        private System.Windows.Forms.RadioButton radSwamp;
        private System.Windows.Forms.RadioButton radMountains;
        private System.Windows.Forms.RadioButton radFlameFields;
        private System.Windows.Forms.RadioButton radFinish;
    }
}