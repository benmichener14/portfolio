﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdventureGame
{
    public partial class ChooseGear : Form
    {
        private String m_itemName = "";
        private Double m_itemCost = 0;
        private int m_quantity = 0;
        public Dictionary<String, int> Inventory = Map.Inv;

        public ChooseGear()
        {
            InitializeComponent();
        }

        //Show Greeting Messages
        private void ChooseGear_Load(object sender, EventArgs e)
        {
            MessageBox.Show("With your Adventurers selected, you can now get supplies for your journey! Rations and Firewood are essential, but you will also be able to find more of both along the way.", "Instructions");
            MessageBox.Show("Everything else, from blankets to horses, has a use somewhere along the adventure. However, these things will be much rarer to find out in the wilds, so be careful to stock up now!", "Instructions");
            txtGold.Text = (Map.gold).ToString();
        }

        //Move on to next form (Map)
        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (Double.Parse(txtGold.Text) >= 0)
            {
                Map.gold = Double.Parse(txtGold.Text);
                Map.Inv = Inventory;
                this.Close();
            }
            else
            {
                MessageBox.Show("You have bought too much! You are now in debt. Get rid of some of that gear.", "Error");
            }
        }

        //Adds an item to your inventory
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtQuantity.Text != "")     //Test to make sure there is a quantity
            {
                m_quantity = Int32.Parse(txtQuantity.Text);
                if (Inventory.ContainsKey(m_itemName))      //If the item is already in Inventory, update quantity
                {
                    int temp = Inventory[m_itemName];
                    Inventory.Remove(m_itemName);
                    Inventory.Add(m_itemName, (m_quantity + temp));
                }
                else            //If not already in Inventory, add to Inventory
                {
                    Inventory.Add(m_itemName, m_quantity);
                }
                lstInventory.Items.Clear();     //Clear Displayed Inventory
                foreach(var item in Inventory)  //Print Full Inventory
                {
                    lstInventory.Items.Add(item.Key + " | " + item.Value);
                }
                txtGold.Text = (Double.Parse(txtGold.Text) - (m_itemCost * m_quantity)).ToString();
            }
            else            //If not quantity, prompt user to enter a quantity
            {
                MessageBox.Show("Please Enter a quantity to buy.", "Error");
            }

            txtQuantity.Text = "";      //Clear quantity text box
        }

        //Removes an instance of the item from your inventory
        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (txtQuantity.Text != "")
            {
                m_quantity = Int32.Parse(txtQuantity.Text);

                if (Inventory.ContainsKey(m_itemName))      //If the item is already in Inventory, update quantity
                {
                    if (m_quantity >= Inventory[m_itemName])    //If trying to remove more than you have, just get rid of it!
                    {
                        m_quantity = Inventory[m_itemName];
                        Inventory.Remove(m_itemName);
                    }
                    else        //Update number of item in inventory
                    {
                        int temp = Inventory[m_itemName];
                        Inventory.Remove(m_itemName);
                        Inventory.Add(m_itemName, (temp - m_quantity));
                    }
                }
                else            //If not already in Inventory, Notify user as such
                {
                    MessageBox.Show("There is none of that item to return.", "Error");
                    m_quantity = 0;
                }
                lstInventory.Items.Clear();     //Clear Displayed Inventory
                foreach (var item in Inventory)  //Print Full Inventory
                {
                    lstInventory.Items.Add(item.Key + " | " + item.Value);
                }
                txtGold.Text = (Double.Parse(txtGold.Text) + (m_itemCost * m_quantity)).ToString();
            }
            else
            {
                MessageBox.Show("Please enter a quantity to remove.", "Error");
            }

        }

        private void radRation_CheckedChanged(object sender, EventArgs e)       //Handles all Rad Checking
        {
            String[] temp = ActiveControl.Text.Split("|".ToCharArray());
            m_itemCost = Double.Parse(temp[0]);
            m_itemName = temp[1].Trim();
        }

        //Displays Help
        private void btnHelp_ChooseParty_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the screen where you can choose what supplies you can take on your adventure. To modify your inventory, check the appropriate radial button for the item you want to choose, enter a quantity to the \"Quantity\" text box, then hit either the \"Add\" or \"Remove\" button.", "Help");
            MessageBox.Show("Once you are finished adding supplies to your inventory, you can click the \"Accept\" button to continue.", "Help");
        }
    }
}
