﻿namespace AdventureGame
{
    partial class ChooseParty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHelp_ChooseParty = new System.Windows.Forms.Button();
            this.cbFighterOne = new System.Windows.Forms.CheckBox();
            this.cbFighterTwo = new System.Windows.Forms.CheckBox();
            this.cbRanger = new System.Windows.Forms.CheckBox();
            this.cbHunter = new System.Windows.Forms.CheckBox();
            this.cbSorcerer = new System.Windows.Forms.CheckBox();
            this.cbWarlock = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbCleric = new System.Windows.Forms.CheckBox();
            this.cbMedic = new System.Windows.Forms.CheckBox();
            this.cbGuide = new System.Windows.Forms.CheckBox();
            this.cbAdventurer = new System.Windows.Forms.CheckBox();
            this.btnAccept = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtGold = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFighterOneName = new System.Windows.Forms.TextBox();
            this.txtFighterTwoName = new System.Windows.Forms.TextBox();
            this.txtRangerName = new System.Windows.Forms.TextBox();
            this.txtHunterName = new System.Windows.Forms.TextBox();
            this.txtSorcererName = new System.Windows.Forms.TextBox();
            this.txtWarlockName = new System.Windows.Forms.TextBox();
            this.txtClericName = new System.Windows.Forms.TextBox();
            this.txtMedicName = new System.Windows.Forms.TextBox();
            this.txtGuideName = new System.Windows.Forms.TextBox();
            this.txtAdventurerName = new System.Windows.Forms.TextBox();
            this.txtAdventurerCost = new System.Windows.Forms.TextBox();
            this.txtGuideCost = new System.Windows.Forms.TextBox();
            this.txtMedicCost = new System.Windows.Forms.TextBox();
            this.txtClericCost = new System.Windows.Forms.TextBox();
            this.txtWarlockCost = new System.Windows.Forms.TextBox();
            this.txtSorcererCost = new System.Windows.Forms.TextBox();
            this.txtHunterCost = new System.Windows.Forms.TextBox();
            this.txtRangerCost = new System.Windows.Forms.TextBox();
            this.txtFighterTwoCost = new System.Windows.Forms.TextBox();
            this.txtFighterOneCost = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnHelp_ChooseParty
            // 
            this.btnHelp_ChooseParty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelp_ChooseParty.Location = new System.Drawing.Point(254, 352);
            this.btnHelp_ChooseParty.Name = "btnHelp_ChooseParty";
            this.btnHelp_ChooseParty.Size = new System.Drawing.Size(30, 23);
            this.btnHelp_ChooseParty.TabIndex = 0;
            this.btnHelp_ChooseParty.Text = "?";
            this.btnHelp_ChooseParty.UseVisualStyleBackColor = true;
            this.btnHelp_ChooseParty.Click += new System.EventHandler(this.btnHelp_ChooseParty_Click);
            // 
            // cbFighterOne
            // 
            this.cbFighterOne.AutoSize = true;
            this.cbFighterOne.Location = new System.Drawing.Point(21, 71);
            this.cbFighterOne.Name = "cbFighterOne";
            this.cbFighterOne.Size = new System.Drawing.Size(58, 17);
            this.cbFighterOne.TabIndex = 1;
            this.cbFighterOne.Text = "Fighter";
            this.cbFighterOne.UseVisualStyleBackColor = true;
            this.cbFighterOne.CheckedChanged += new System.EventHandler(this.cbFighterOne_CheckedChanged);
            // 
            // cbFighterTwo
            // 
            this.cbFighterTwo.AutoSize = true;
            this.cbFighterTwo.Location = new System.Drawing.Point(21, 94);
            this.cbFighterTwo.Name = "cbFighterTwo";
            this.cbFighterTwo.Size = new System.Drawing.Size(58, 17);
            this.cbFighterTwo.TabIndex = 2;
            this.cbFighterTwo.Text = "Fighter";
            this.cbFighterTwo.UseVisualStyleBackColor = true;
            this.cbFighterTwo.CheckedChanged += new System.EventHandler(this.cbFighterTwo_CheckedChanged);
            // 
            // cbRanger
            // 
            this.cbRanger.AutoSize = true;
            this.cbRanger.Location = new System.Drawing.Point(21, 117);
            this.cbRanger.Name = "cbRanger";
            this.cbRanger.Size = new System.Drawing.Size(61, 17);
            this.cbRanger.TabIndex = 3;
            this.cbRanger.Text = "Ranger";
            this.cbRanger.UseVisualStyleBackColor = true;
            this.cbRanger.CheckedChanged += new System.EventHandler(this.cbRanger_CheckedChanged);
            // 
            // cbHunter
            // 
            this.cbHunter.AutoSize = true;
            this.cbHunter.Location = new System.Drawing.Point(21, 140);
            this.cbHunter.Name = "cbHunter";
            this.cbHunter.Size = new System.Drawing.Size(58, 17);
            this.cbHunter.TabIndex = 4;
            this.cbHunter.Text = "Hunter";
            this.cbHunter.UseVisualStyleBackColor = true;
            this.cbHunter.CheckedChanged += new System.EventHandler(this.cbHunter_CheckedChanged);
            // 
            // cbSorcerer
            // 
            this.cbSorcerer.AutoSize = true;
            this.cbSorcerer.Location = new System.Drawing.Point(21, 163);
            this.cbSorcerer.Name = "cbSorcerer";
            this.cbSorcerer.Size = new System.Drawing.Size(66, 17);
            this.cbSorcerer.TabIndex = 5;
            this.cbSorcerer.Text = "Sorcerer";
            this.cbSorcerer.UseVisualStyleBackColor = true;
            this.cbSorcerer.CheckedChanged += new System.EventHandler(this.cbSorcerer_CheckedChanged);
            // 
            // cbWarlock
            // 
            this.cbWarlock.AutoSize = true;
            this.cbWarlock.Location = new System.Drawing.Point(21, 186);
            this.cbWarlock.Name = "cbWarlock";
            this.cbWarlock.Size = new System.Drawing.Size(66, 17);
            this.cbWarlock.TabIndex = 6;
            this.cbWarlock.Text = "Warlock";
            this.cbWarlock.UseVisualStyleBackColor = true;
            this.cbWarlock.CheckedChanged += new System.EventHandler(this.cbWarlock_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 33);
            this.label1.TabIndex = 7;
            this.label1.Text = "Choose Your Party";
            // 
            // cbCleric
            // 
            this.cbCleric.AutoSize = true;
            this.cbCleric.Location = new System.Drawing.Point(21, 209);
            this.cbCleric.Name = "cbCleric";
            this.cbCleric.Size = new System.Drawing.Size(52, 17);
            this.cbCleric.TabIndex = 8;
            this.cbCleric.Text = "Cleric";
            this.cbCleric.UseVisualStyleBackColor = true;
            this.cbCleric.CheckedChanged += new System.EventHandler(this.cbCleric_CheckedChanged);
            // 
            // cbMedic
            // 
            this.cbMedic.AutoSize = true;
            this.cbMedic.Location = new System.Drawing.Point(21, 232);
            this.cbMedic.Name = "cbMedic";
            this.cbMedic.Size = new System.Drawing.Size(55, 17);
            this.cbMedic.TabIndex = 9;
            this.cbMedic.Text = "Medic";
            this.cbMedic.UseVisualStyleBackColor = true;
            this.cbMedic.CheckedChanged += new System.EventHandler(this.cbMedic_CheckedChanged);
            // 
            // cbGuide
            // 
            this.cbGuide.AutoSize = true;
            this.cbGuide.Location = new System.Drawing.Point(21, 255);
            this.cbGuide.Name = "cbGuide";
            this.cbGuide.Size = new System.Drawing.Size(54, 17);
            this.cbGuide.TabIndex = 10;
            this.cbGuide.Text = "Guide";
            this.cbGuide.UseVisualStyleBackColor = true;
            this.cbGuide.CheckedChanged += new System.EventHandler(this.cbGuide_CheckedChanged);
            // 
            // cbAdventurer
            // 
            this.cbAdventurer.AutoSize = true;
            this.cbAdventurer.Location = new System.Drawing.Point(21, 278);
            this.cbAdventurer.Name = "cbAdventurer";
            this.cbAdventurer.Size = new System.Drawing.Size(78, 17);
            this.cbAdventurer.TabIndex = 11;
            this.cbAdventurer.Text = "Adventurer";
            this.cbAdventurer.UseVisualStyleBackColor = true;
            this.cbAdventurer.CheckedChanged += new System.EventHandler(this.cbAdventurer_CheckedChanged);
            // 
            // btnAccept
            // 
            this.btnAccept.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccept.Location = new System.Drawing.Point(12, 309);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(75, 55);
            this.btnAccept.TabIndex = 12;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(93, 318);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Current Gold:";
            // 
            // txtGold
            // 
            this.txtGold.Location = new System.Drawing.Point(93, 334);
            this.txtGold.Name = "txtGold";
            this.txtGold.ReadOnly = true;
            this.txtGold.Size = new System.Drawing.Size(69, 20);
            this.txtGold.TabIndex = 14;
            this.txtGold.Text = "1000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(111, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(215, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 20);
            this.label5.TabIndex = 17;
            this.label5.Text = "Cost";
            // 
            // txtFighterOneName
            // 
            this.txtFighterOneName.Location = new System.Drawing.Point(112, 68);
            this.txtFighterOneName.Name = "txtFighterOneName";
            this.txtFighterOneName.ReadOnly = true;
            this.txtFighterOneName.Size = new System.Drawing.Size(50, 20);
            this.txtFighterOneName.TabIndex = 19;
            this.txtFighterOneName.Text = "Klarissa";
            this.txtFighterOneName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFighterOneName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtFighterTwoName
            // 
            this.txtFighterTwoName.Location = new System.Drawing.Point(112, 91);
            this.txtFighterTwoName.Name = "txtFighterTwoName";
            this.txtFighterTwoName.ReadOnly = true;
            this.txtFighterTwoName.Size = new System.Drawing.Size(50, 20);
            this.txtFighterTwoName.TabIndex = 20;
            this.txtFighterTwoName.Text = "Jupp";
            this.txtFighterTwoName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFighterTwoName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtRangerName
            // 
            this.txtRangerName.Location = new System.Drawing.Point(112, 114);
            this.txtRangerName.Name = "txtRangerName";
            this.txtRangerName.ReadOnly = true;
            this.txtRangerName.Size = new System.Drawing.Size(50, 20);
            this.txtRangerName.TabIndex = 21;
            this.txtRangerName.Text = "Abel";
            this.txtRangerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRangerName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtHunterName
            // 
            this.txtHunterName.Location = new System.Drawing.Point(112, 137);
            this.txtHunterName.Name = "txtHunterName";
            this.txtHunterName.ReadOnly = true;
            this.txtHunterName.Size = new System.Drawing.Size(50, 20);
            this.txtHunterName.TabIndex = 22;
            this.txtHunterName.Text = "Solaine";
            this.txtHunterName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtHunterName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtSorcererName
            // 
            this.txtSorcererName.Location = new System.Drawing.Point(112, 160);
            this.txtSorcererName.Name = "txtSorcererName";
            this.txtSorcererName.ReadOnly = true;
            this.txtSorcererName.Size = new System.Drawing.Size(50, 20);
            this.txtSorcererName.TabIndex = 23;
            this.txtSorcererName.Text = "Kegan";
            this.txtSorcererName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSorcererName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtWarlockName
            // 
            this.txtWarlockName.Location = new System.Drawing.Point(112, 183);
            this.txtWarlockName.Name = "txtWarlockName";
            this.txtWarlockName.ReadOnly = true;
            this.txtWarlockName.Size = new System.Drawing.Size(50, 20);
            this.txtWarlockName.TabIndex = 24;
            this.txtWarlockName.Text = "Emmery";
            this.txtWarlockName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWarlockName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtClericName
            // 
            this.txtClericName.Location = new System.Drawing.Point(112, 206);
            this.txtClericName.Name = "txtClericName";
            this.txtClericName.ReadOnly = true;
            this.txtClericName.Size = new System.Drawing.Size(50, 20);
            this.txtClericName.TabIndex = 25;
            this.txtClericName.Text = "Gerd";
            this.txtClericName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtClericName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtMedicName
            // 
            this.txtMedicName.Location = new System.Drawing.Point(112, 229);
            this.txtMedicName.Name = "txtMedicName";
            this.txtMedicName.ReadOnly = true;
            this.txtMedicName.Size = new System.Drawing.Size(50, 20);
            this.txtMedicName.TabIndex = 26;
            this.txtMedicName.Text = "Volkan";
            this.txtMedicName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMedicName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtGuideName
            // 
            this.txtGuideName.Location = new System.Drawing.Point(112, 252);
            this.txtGuideName.Name = "txtGuideName";
            this.txtGuideName.ReadOnly = true;
            this.txtGuideName.Size = new System.Drawing.Size(50, 20);
            this.txtGuideName.TabIndex = 27;
            this.txtGuideName.Text = "Jakob";
            this.txtGuideName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtGuideName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtAdventurerName
            // 
            this.txtAdventurerName.Location = new System.Drawing.Point(112, 275);
            this.txtAdventurerName.Name = "txtAdventurerName";
            this.txtAdventurerName.ReadOnly = true;
            this.txtAdventurerName.Size = new System.Drawing.Size(50, 20);
            this.txtAdventurerName.TabIndex = 28;
            this.txtAdventurerName.Text = "Merci";
            this.txtAdventurerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAdventurerName.DoubleClick += new System.EventHandler(this.txtFighterOne_DoubleClick);
            // 
            // txtAdventurerCost
            // 
            this.txtAdventurerCost.Location = new System.Drawing.Point(194, 275);
            this.txtAdventurerCost.Name = "txtAdventurerCost";
            this.txtAdventurerCost.ReadOnly = true;
            this.txtAdventurerCost.Size = new System.Drawing.Size(82, 20);
            this.txtAdventurerCost.TabIndex = 38;
            this.txtAdventurerCost.Text = "50";
            this.txtAdventurerCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtGuideCost
            // 
            this.txtGuideCost.Location = new System.Drawing.Point(194, 252);
            this.txtGuideCost.Name = "txtGuideCost";
            this.txtGuideCost.ReadOnly = true;
            this.txtGuideCost.Size = new System.Drawing.Size(82, 20);
            this.txtGuideCost.TabIndex = 37;
            this.txtGuideCost.Text = "50";
            this.txtGuideCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMedicCost
            // 
            this.txtMedicCost.Location = new System.Drawing.Point(194, 229);
            this.txtMedicCost.Name = "txtMedicCost";
            this.txtMedicCost.ReadOnly = true;
            this.txtMedicCost.Size = new System.Drawing.Size(82, 20);
            this.txtMedicCost.TabIndex = 36;
            this.txtMedicCost.Text = "100";
            this.txtMedicCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtClericCost
            // 
            this.txtClericCost.Location = new System.Drawing.Point(194, 206);
            this.txtClericCost.Name = "txtClericCost";
            this.txtClericCost.ReadOnly = true;
            this.txtClericCost.Size = new System.Drawing.Size(82, 20);
            this.txtClericCost.TabIndex = 35;
            this.txtClericCost.Text = "250";
            this.txtClericCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtWarlockCost
            // 
            this.txtWarlockCost.Location = new System.Drawing.Point(194, 183);
            this.txtWarlockCost.Name = "txtWarlockCost";
            this.txtWarlockCost.ReadOnly = true;
            this.txtWarlockCost.Size = new System.Drawing.Size(82, 20);
            this.txtWarlockCost.TabIndex = 34;
            this.txtWarlockCost.Text = "250";
            this.txtWarlockCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSorcererCost
            // 
            this.txtSorcererCost.Location = new System.Drawing.Point(194, 160);
            this.txtSorcererCost.Name = "txtSorcererCost";
            this.txtSorcererCost.ReadOnly = true;
            this.txtSorcererCost.Size = new System.Drawing.Size(82, 20);
            this.txtSorcererCost.TabIndex = 33;
            this.txtSorcererCost.Text = "150";
            this.txtSorcererCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHunterCost
            // 
            this.txtHunterCost.Location = new System.Drawing.Point(194, 137);
            this.txtHunterCost.Name = "txtHunterCost";
            this.txtHunterCost.ReadOnly = true;
            this.txtHunterCost.Size = new System.Drawing.Size(82, 20);
            this.txtHunterCost.TabIndex = 32;
            this.txtHunterCost.Text = "200";
            this.txtHunterCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtRangerCost
            // 
            this.txtRangerCost.Location = new System.Drawing.Point(194, 114);
            this.txtRangerCost.Name = "txtRangerCost";
            this.txtRangerCost.ReadOnly = true;
            this.txtRangerCost.Size = new System.Drawing.Size(82, 20);
            this.txtRangerCost.TabIndex = 31;
            this.txtRangerCost.Text = "150";
            this.txtRangerCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFighterTwoCost
            // 
            this.txtFighterTwoCost.Location = new System.Drawing.Point(194, 91);
            this.txtFighterTwoCost.Name = "txtFighterTwoCost";
            this.txtFighterTwoCost.ReadOnly = true;
            this.txtFighterTwoCost.Size = new System.Drawing.Size(82, 20);
            this.txtFighterTwoCost.TabIndex = 30;
            this.txtFighterTwoCost.Text = "150";
            this.txtFighterTwoCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFighterOneCost
            // 
            this.txtFighterOneCost.Location = new System.Drawing.Point(194, 68);
            this.txtFighterOneCost.Name = "txtFighterOneCost";
            this.txtFighterOneCost.ReadOnly = true;
            this.txtFighterOneCost.Size = new System.Drawing.Size(82, 20);
            this.txtFighterOneCost.TabIndex = 29;
            this.txtFighterOneCost.Text = "100";
            this.txtFighterOneCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ChooseParty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 376);
            this.Controls.Add(this.txtAdventurerCost);
            this.Controls.Add(this.txtGuideCost);
            this.Controls.Add(this.txtMedicCost);
            this.Controls.Add(this.txtClericCost);
            this.Controls.Add(this.txtWarlockCost);
            this.Controls.Add(this.txtSorcererCost);
            this.Controls.Add(this.txtHunterCost);
            this.Controls.Add(this.txtRangerCost);
            this.Controls.Add(this.txtFighterTwoCost);
            this.Controls.Add(this.txtFighterOneCost);
            this.Controls.Add(this.txtAdventurerName);
            this.Controls.Add(this.txtGuideName);
            this.Controls.Add(this.txtMedicName);
            this.Controls.Add(this.txtClericName);
            this.Controls.Add(this.txtWarlockName);
            this.Controls.Add(this.txtSorcererName);
            this.Controls.Add(this.txtHunterName);
            this.Controls.Add(this.txtRangerName);
            this.Controls.Add(this.txtFighterTwoName);
            this.Controls.Add(this.txtFighterOneName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtGold);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.cbAdventurer);
            this.Controls.Add(this.cbGuide);
            this.Controls.Add(this.cbMedic);
            this.Controls.Add(this.cbCleric);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbWarlock);
            this.Controls.Add(this.cbSorcerer);
            this.Controls.Add(this.cbHunter);
            this.Controls.Add(this.cbRanger);
            this.Controls.Add(this.cbFighterTwo);
            this.Controls.Add(this.cbFighterOne);
            this.Controls.Add(this.btnHelp_ChooseParty);
            this.Name = "ChooseParty";
            this.Text = "ChooseParty";
            this.Load += new System.EventHandler(this.ChooseParty_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHelp_ChooseParty;
        private System.Windows.Forms.CheckBox cbFighterOne;
        private System.Windows.Forms.CheckBox cbFighterTwo;
        private System.Windows.Forms.CheckBox cbRanger;
        private System.Windows.Forms.CheckBox cbHunter;
        private System.Windows.Forms.CheckBox cbSorcerer;
        private System.Windows.Forms.CheckBox cbWarlock;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbCleric;
        private System.Windows.Forms.CheckBox cbMedic;
        private System.Windows.Forms.CheckBox cbGuide;
        private System.Windows.Forms.CheckBox cbAdventurer;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtGold;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFighterOneName;
        private System.Windows.Forms.TextBox txtFighterTwoName;
        private System.Windows.Forms.TextBox txtRangerName;
        private System.Windows.Forms.TextBox txtHunterName;
        private System.Windows.Forms.TextBox txtSorcererName;
        private System.Windows.Forms.TextBox txtWarlockName;
        private System.Windows.Forms.TextBox txtClericName;
        private System.Windows.Forms.TextBox txtMedicName;
        private System.Windows.Forms.TextBox txtGuideName;
        private System.Windows.Forms.TextBox txtAdventurerName;
        private System.Windows.Forms.TextBox txtAdventurerCost;
        private System.Windows.Forms.TextBox txtGuideCost;
        private System.Windows.Forms.TextBox txtMedicCost;
        private System.Windows.Forms.TextBox txtClericCost;
        private System.Windows.Forms.TextBox txtWarlockCost;
        private System.Windows.Forms.TextBox txtSorcererCost;
        private System.Windows.Forms.TextBox txtHunterCost;
        private System.Windows.Forms.TextBox txtRangerCost;
        private System.Windows.Forms.TextBox txtFighterTwoCost;
        private System.Windows.Forms.TextBox txtFighterOneCost;
    }
}

