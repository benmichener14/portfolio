﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace AdventureGame
{
    public partial class Combat : Form
    {
        Random random = new Random();
        private Stats monsterStats;
        public Combat()
        {
            InitializeComponent();
        }

        private void Combat_Load(object sender, EventArgs e)        //Creates encounter table based on region player is in and chooses a random enemy for the player to fight
        {
            StreamReader sr = new StreamReader(Map.location + "_enemies.txt");
            String line = sr.ReadLine();
            List<string> encounterTable = new List<string>();
            while (line != null)
            {
                encounterTable.Add(line);
                line = sr.ReadLine();
            }

            String monster = encounterTable[random.Next(20)];
            String[] temp = monster.Split();
            MessageBox.Show("You are going to be fighting " + temp[0]);
            monsterStats = new Stats(temp[0],( Double.Parse(temp[1]) * (random.Next(Int32.Parse(temp[5])) + 1)), Double.Parse(temp[2]), Double.Parse(temp[3]), Double.Parse(temp[4]), random.Next(Int32.Parse(temp[5])) + 1);

            if (monsterStats.Num > 1)
                txtCombatLog.Text += monsterStats.Num + " " + monsterStats.Name + "s appear! They begin moving towards you, ready to attack! It's time to fight! \r\n\r\n";
            else
                txtCombatLog.Text += "A " + monsterStats.Name + " appears! It begins moving towards you, ready to attack! It's time to fight! \r\n\r\n";
        }

        private void btnCheckParty_Click(object sender, EventArgs e)
        {
            String partyDisplay = "Name: \t Con \t Dex \t Str \t Skill \n";
            foreach (var person in Map.Adventurers.Keys)
            {
                partyDisplay += Map.Adventurers[person].Name + " \t";
                partyDisplay += Map.Adventurers[person].Con + " \t";
                partyDisplay += Map.Adventurers[person].Dex + " \t";
                partyDisplay += Map.Adventurers[person].Str + " \t";
                partyDisplay += Map.Adventurers[person].Skill + " \n";
            }
            MessageBox.Show(partyDisplay, "Party:");
        }       //Shows Party Stats

        private void btnCheckEnemies_Click(object sender, EventArgs e)
        {
            String partyDisplay = "Name: \t Con \t Dex \t Str \t Skill \t Number \n";

                partyDisplay += monsterStats.Name + " \t";
                partyDisplay += monsterStats.Con + " \t";
                partyDisplay += monsterStats.Dex + " \t";
                partyDisplay += monsterStats.Str + " \t";
                partyDisplay += monsterStats.Skill + " \t";
                partyDisplay += monsterStats.Num + "\n";

            MessageBox.Show(partyDisplay, "Monster:");
        }     //Shows enemy stats

        private void btnTakeAction_Click(object sender, EventArgs e)          //Dictates what action the player is taking in this turn of combat
        {
            if(radAttack.Checked == true)
            {
                playerAttack();
                if (monsterStats.Con > 0)
                {
                    monsterAttack();
                }
                else
                {
                    MessageBox.Show("You were successful!");
                    this.Close();
                }
            }

            if(radDefend.Checked == true)
            {
                playerDefend();
            }

            checkParty();

            if(radRetreat.Checked == true)
            {
                MessageBox.Show("You turn and run, fleeing from the creature.");
                monsterAttack();
                checkParty();
                this.Close();
            }
        }
        //Player gets a chance to attack (in which the monster deals full damage back), the player can defend (in which their dex is temporarily increased above 1),
        //or the player can retreat from battle (in which the monster gets an attack of opportunity)
        //At the end of combat, the monster's next attack damage is calculated, and a prediction as to the power of the next attack will be given (to provide an opportunity to defend in anticipation)

        private void playerAttack()
        {
            txtCombatLog.Text = ("\nIt is the party's turn to attack... \r\n\r\n");     //Clears display as well
            foreach (var member in Map.Adventurers.Keys)
            {
                if((random.Next(10) + 1) * (monsterStats.Dex) < (Map.Adventurers[member.ToString()].Skill * (random.Next(10) + 1)))  //Algorithm: (monster dex * random 1-10 ) < (adventurer skill * random 1-10)
                {
                    int damage = attack(Map.Adventurers[member.ToString()].Str);

                    //Deal damage to enemies
                    monsterStats.Con -= damage;
                    txtCombatLog.Text += (member.ToString() + " hits, dealing " + damage + " damage! \r\n");
                }
                else
                {
                    txtCombatLog.Text += (member.ToString() + " misses, dealing no damage. \r\n");
                }
            }
        }

        private void playerDefend()
        {
            txtCombatLog.Text = ("\nThe party is being attacked... \r\n\r\n");
            for (int i = 0; i < monsterStats.Num; i++)
            {
                //Choose party member
                List<String> temp = new List<string>(Map.Adventurers.Keys);
                String hit = temp[random.Next(Map.Adventurers.Count())];

                if ((random.Next(10) + 1) * 1 < (monsterStats.Skill) * (random.Next(10) + 1))      //Sets player dex to 1
                {
                    int damage = 1;     //Sets damage == 1

                    //Deal damage to party
                    Map.Adventurers[hit].Con -= damage;

                    txtCombatLog.Text += ("A " + monsterStats.Name + " hits " + hit + ", dealing " + damage + " damage! \r\n");
                }
                else
                {
                    txtCombatLog.Text += ("A " + monsterStats.Name + " misses, dealing no damage. \r\n");
                }
            }
        }

        private void monsterAttack()
        {
            txtCombatLog.Text += ("\nThe party is being attacked... \r\n\r\n");
            for(int i = 0; i < monsterStats.Num; i++)
            {
                //Choose party member
                List<String> temp = new List<string>(Map.Adventurers.Keys);
                String hit = temp[random.Next(Map.Adventurers.Count())];

                if ((random.Next(10) + 1) * Map.Adventurers[hit].Dex < (monsterStats.Skill) * (random.Next(10) + 1))
                {
                    int damage = attack(monsterStats.Str);

                    //Deal damage to party
                    Map.Adventurers[hit].Con -= damage;

                    txtCombatLog.Text += ("A " + monsterStats.Name + " hits " + hit +", dealing " + damage + " damage! \r\n");
                }
                else
                {
                    txtCombatLog.Text += ("A " + monsterStats.Name + " misses, dealing no damage. \r\n");
                }
            }
        }

        //Calculates damage
        private int attack(double strength)
        {
            int damage = random.Next(Convert.ToInt32(strength)) + 1;
            return damage;
        }

        private void checkParty()
        {
            List<String> toRemove = new List<string>();
            foreach (var member in Map.Adventurers.Keys)
            {
                if(Map.Adventurers[member].Con <= 0)
                {
                    toRemove.Add(member);
                    MessageBox.Show(member + " has died.");
                }
            }

            foreach(string person in toRemove)
            {
                Map.Adventurers.Remove(person);
            }

            if(Map.Adventurers.Count() == 0)
            {
                MessageBox.Show("As your last adventurer passes away, you realize that your adventure has failed.", "Game Over");
                this.Close();
            }

       }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the combat screen. This is where you fight enemies on your adventure!", "Help");
            MessageBox.Show("On each round, you have the opportunity to either attack, defend, or retreat. After you take your action, the monster will have an opportunity to respond.", "Help");
            MessageBox.Show("Combat will end when you have defeated the monsters, or the monsters have defeated you. Once a monster's (or player's) constitution stat hits zero, they die.", "Help");
        }
    }
}
