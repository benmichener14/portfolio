﻿namespace AdventureGame
{
    partial class ChooseGear
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtGold = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAccept = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lstInventory = new System.Windows.Forms.ListBox();
            this.radRation = new System.Windows.Forms.RadioButton();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.radFirewood = new System.Windows.Forms.RadioButton();
            this.radArrows = new System.Windows.Forms.RadioButton();
            this.radBlanket = new System.Windows.Forms.RadioButton();
            this.radPotion = new System.Windows.Forms.RadioButton();
            this.radRope = new System.Windows.Forms.RadioButton();
            this.radCloak = new System.Windows.Forms.RadioButton();
            this.radHorse = new System.Windows.Forms.RadioButton();
            this.btnHelp_ChooseParty = new System.Windows.Forms.Button();
            this.txtQuantity = new System.Windows.Forms.MaskedTextBox();
            this.lblCost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtGold
            // 
            this.txtGold.Location = new System.Drawing.Point(222, 276);
            this.txtGold.Name = "txtGold";
            this.txtGold.ReadOnly = true;
            this.txtGold.Size = new System.Drawing.Size(135, 20);
            this.txtGold.TabIndex = 17;
            this.txtGold.Text = "1000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(219, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Current Gold:";
            // 
            // btnAccept
            // 
            this.btnAccept.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccept.Location = new System.Drawing.Point(222, 302);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(135, 55);
            this.btnAccept.TabIndex = 15;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(274, 33);
            this.label1.TabIndex = 18;
            this.label1.Text = "Choose Your Gear";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(60, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 20);
            this.label3.TabIndex = 19;
            this.label3.Text = "Equipment";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 312);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 20;
            this.label4.Text = "Quantitiy";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(252, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 20);
            this.label5.TabIndex = 21;
            this.label5.Text = "Inventory";
            // 
            // lstInventory
            // 
            this.lstInventory.FormattingEnabled = true;
            this.lstInventory.Location = new System.Drawing.Point(222, 84);
            this.lstInventory.Name = "lstInventory";
            this.lstInventory.Size = new System.Drawing.Size(135, 160);
            this.lstInventory.TabIndex = 22;
            // 
            // radRation
            // 
            this.radRation.AutoSize = true;
            this.radRation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radRation.Location = new System.Drawing.Point(16, 84);
            this.radRation.Name = "radRation";
            this.radRation.Size = new System.Drawing.Size(88, 20);
            this.radRation.TabIndex = 23;
            this.radRation.TabStop = true;
            this.radRation.Text = "10 | Ration";
            this.radRation.UseVisualStyleBackColor = true;
            this.radRation.CheckedChanged += new System.EventHandler(this.radRation_CheckedChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(84, 312);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(62, 45);
            this.btnAdd.TabIndex = 25;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(152, 312);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(62, 45);
            this.btnRemove.TabIndex = 26;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // radFirewood
            // 
            this.radFirewood.AutoSize = true;
            this.radFirewood.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radFirewood.Location = new System.Drawing.Point(16, 110);
            this.radFirewood.Name = "radFirewood";
            this.radFirewood.Size = new System.Drawing.Size(105, 20);
            this.radFirewood.TabIndex = 27;
            this.radFirewood.TabStop = true;
            this.radFirewood.Text = "20 | Firewood";
            this.radFirewood.UseVisualStyleBackColor = true;
            this.radFirewood.CheckedChanged += new System.EventHandler(this.radRation_CheckedChanged);
            // 
            // radArrows
            // 
            this.radArrows.AutoSize = true;
            this.radArrows.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radArrows.Location = new System.Drawing.Point(16, 136);
            this.radArrows.Name = "radArrows";
            this.radArrows.Size = new System.Drawing.Size(115, 20);
            this.radArrows.TabIndex = 28;
            this.radArrows.TabStop = true;
            this.radArrows.Text = "25 | Arrows (20)";
            this.radArrows.UseVisualStyleBackColor = true;
            this.radArrows.CheckedChanged += new System.EventHandler(this.radRation_CheckedChanged);
            // 
            // radBlanket
            // 
            this.radBlanket.AutoSize = true;
            this.radBlanket.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radBlanket.Location = new System.Drawing.Point(16, 162);
            this.radBlanket.Name = "radBlanket";
            this.radBlanket.Size = new System.Drawing.Size(137, 20);
            this.radBlanket.TabIndex = 29;
            this.radBlanket.TabStop = true;
            this.radBlanket.Text = "15 | Heavy Blanket";
            this.radBlanket.UseVisualStyleBackColor = true;
            this.radBlanket.CheckedChanged += new System.EventHandler(this.radRation_CheckedChanged);
            // 
            // radPotion
            // 
            this.radPotion.AutoSize = true;
            this.radPotion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radPotion.Location = new System.Drawing.Point(16, 188);
            this.radPotion.Name = "radPotion";
            this.radPotion.Size = new System.Drawing.Size(137, 20);
            this.radPotion.TabIndex = 30;
            this.radPotion.TabStop = true;
            this.radPotion.Text = "75 | Healing Potion";
            this.radPotion.UseVisualStyleBackColor = true;
            this.radPotion.CheckedChanged += new System.EventHandler(this.radRation_CheckedChanged);
            // 
            // radRope
            // 
            this.radRope.AutoSize = true;
            this.radRope.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radRope.Location = new System.Drawing.Point(16, 214);
            this.radRope.Name = "radRope";
            this.radRope.Size = new System.Drawing.Size(172, 20);
            this.radRope.TabIndex = 31;
            this.radRope.TabStop = true;
            this.radRope.Text = "40 | Hempen Rope (60 ft)";
            this.radRope.UseVisualStyleBackColor = true;
            this.radRope.CheckedChanged += new System.EventHandler(this.radRation_CheckedChanged);
            // 
            // radCloak
            // 
            this.radCloak.AutoSize = true;
            this.radCloak.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radCloak.Location = new System.Drawing.Point(16, 240);
            this.radCloak.Name = "radCloak";
            this.radCloak.Size = new System.Drawing.Size(154, 20);
            this.radCloak.TabIndex = 32;
            this.radCloak.TabStop = true;
            this.radCloak.Text = "40 | Waterproof Cloak";
            this.radCloak.UseVisualStyleBackColor = true;
            this.radCloak.CheckedChanged += new System.EventHandler(this.radRation_CheckedChanged);
            // 
            // radHorse
            // 
            this.radHorse.AutoSize = true;
            this.radHorse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radHorse.Location = new System.Drawing.Point(16, 266);
            this.radHorse.Name = "radHorse";
            this.radHorse.Size = new System.Drawing.Size(86, 20);
            this.radHorse.TabIndex = 33;
            this.radHorse.TabStop = true;
            this.radHorse.Text = "95 | Horse";
            this.radHorse.UseVisualStyleBackColor = true;
            this.radHorse.CheckedChanged += new System.EventHandler(this.radRation_CheckedChanged);
            // 
            // btnHelp_ChooseParty
            // 
            this.btnHelp_ChooseParty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelp_ChooseParty.Location = new System.Drawing.Point(327, 12);
            this.btnHelp_ChooseParty.Name = "btnHelp_ChooseParty";
            this.btnHelp_ChooseParty.Size = new System.Drawing.Size(30, 23);
            this.btnHelp_ChooseParty.TabIndex = 34;
            this.btnHelp_ChooseParty.Text = "?";
            this.btnHelp_ChooseParty.UseVisualStyleBackColor = true;
            this.btnHelp_ChooseParty.Click += new System.EventHandler(this.btnHelp_ChooseParty_Click);
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(11, 337);
            this.txtQuantity.Mask = "0000000000";
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(68, 20);
            this.txtQuantity.TabIndex = 35;
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.Location = new System.Drawing.Point(7, 52);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(42, 20);
            this.lblCost.TabIndex = 36;
            this.lblCost.Text = "Cost";
            // 
            // ChooseGear
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 369);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.btnHelp_ChooseParty);
            this.Controls.Add(this.radHorse);
            this.Controls.Add(this.radCloak);
            this.Controls.Add(this.radRope);
            this.Controls.Add(this.radPotion);
            this.Controls.Add(this.radBlanket);
            this.Controls.Add(this.radArrows);
            this.Controls.Add(this.radFirewood);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.radRation);
            this.Controls.Add(this.lstInventory);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtGold);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAccept);
            this.Name = "ChooseGear";
            this.Text = "ChooseGear";
            this.Load += new System.EventHandler(this.ChooseGear_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtGold;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lstInventory;
        private System.Windows.Forms.RadioButton radRation;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.RadioButton radFirewood;
        private System.Windows.Forms.RadioButton radArrows;
        private System.Windows.Forms.RadioButton radBlanket;
        private System.Windows.Forms.RadioButton radPotion;
        private System.Windows.Forms.RadioButton radRope;
        private System.Windows.Forms.RadioButton radCloak;
        private System.Windows.Forms.RadioButton radHorse;
        private System.Windows.Forms.Button btnHelp_ChooseParty;
        private System.Windows.Forms.MaskedTextBox txtQuantity;
        private System.Windows.Forms.Label lblCost;
    }
}