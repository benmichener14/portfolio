﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//"Main"
namespace AdventureGame
{
    public partial class Map : Form
    {
        public static Dictionary<String, int> Inv = new Dictionary<string, int>();
        public static Dictionary<String, Stats> Adventurers = new Dictionary<String, Stats>();
        public static double gold;
        public static String location;
        private int time;
        private int timeToDestination;  //counts down time to reaching each milestone. At zero, makes the player choose a new place to go to.
        private String currentLocation = "Plains";
        private String nextDestination = "";

        Random random = new Random();

        public Map()
        {
            InitializeComponent();
            gold = 1000;
            time = 8;
            location = "Coast";
        }

        private void Map_Load(object sender, EventArgs e)
        {
            String betaMessage = "As of current, this is to be considered a working Beta. The following features are fully working: \n";
            betaMessage += "\t-Party Select \n\t-Inventory Select \n\t-Combat with randomized encounters from a text file \n\t-Time, resource usage, and basic daily schedule\n\n";
            betaMessage += "To be implimented: \n\t-Map Traversal (75% implemented) \n\t-More random lists (0% implemented) \n\t-Descriptions and flavor text (0% implemented) \n\t-Balancing of Stats";
            betaMessage += "\n\nBecause of the time restrictions, and the cosmetic nature of the things to be added (most of them require very little coding and a lot of playtesting and tweaking), I am considering this project, for the sake of the assignment, finished.";
            MessageBox.Show(betaMessage);
            ChooseParty PartySelect = new AdventureGame.ChooseParty();
            PartySelect.ShowDialog();
            txtCurrentTime.Text = time + ":00";
        }

        private void passTime(int timepassed) //Passes time by a given amount, and loops time if ticking over to next day
        {
            time += timepassed;
            if (time > 23)
                time -= 24;
            txtCurrentTime.Text = time + ":00";
        }

        private void btnCheckInventory_Click(object sender, EventArgs e) //Displays inventory for player to look at in the form of a MessageBox
        {
            String inventoryDisplay = "Inventory: \n\n";
            foreach (var item in Inv.Keys)
            {
                inventoryDisplay += "\t" + item + " | " + Inv[item] + "\n";
            }
            MessageBox.Show(inventoryDisplay, "Inventory");
        }

        private void btnCheckParty_Click(object sender, EventArgs e) //Displays party for player to check the stats of in the form of a MessageBox
        {
            String partyDisplay = "Name: \t Con \t Dex \t Str \t Skill \n";
            foreach (var person in Adventurers.Keys)
            {
                partyDisplay += Adventurers[person].Name + " \t";
                partyDisplay += Adventurers[person].Con + " \t";
                partyDisplay += Adventurers[person].Dex + " \t";
                partyDisplay += Adventurers[person].Str + " \t";
                partyDisplay += Adventurers[person].Skill + " \n";
            }
            MessageBox.Show(partyDisplay, "Party:");
        }

        private void btnFood_Click(object sender, EventArgs e) //Gives the player the opportunity to spend an hour for a chance at getting some rations
        {
            passTime(1);
            if (random.Next(10) < 5)
            {
                MessageBox.Show("You take an hour to search for firewood. Thankfully, you find a small supply to add to your inventory.", "Firewood");
                if (Inv.ContainsKey("Firewood"))
                {
                    Inv["Firewood"] += random.Next(5);
                }
                else
                {
                    Inv.Add("Firewood", random.Next(5));
                }
            }
            else
            {
                MessageBox.Show("You take an hour to search for firewood. Unfortunately, you find none.", "Firewood");
            }
        }

        private void btnFirewood_Click(object sender, EventArgs e) //Gives the player the opportunity to spend an hour for a chance at getting some firewood
        {
            passTime(1);
            if (random.Next(10) < 3)
            {
                if (Inv.ContainsKey("Arrows(20)"))
                {
                    MessageBox.Show("You take an hour to search for food. You manage to use some of your arrows to catch a small animal. Some rations have been added to your inventory", "Hunting");
                    if (Inv.ContainsKey("Ration"))
                    {
                        Inv["Ration"] += (random.Next(5) + 1);
                    }
                    else
                    {
                        Inv.Add("Ration", (random.Next(5) + 1));
                    }
                }
                else
                {
                    MessageBox.Show("You take an hour to search for food. You manage to find a few edible plants. Some rations have been added to your inventory", "Gathering");
                    if (Inv.ContainsKey("Ration"))
                    {
                        Inv["Ration"] += (random.Next(2) + 1);
                    }
                    else
                    {
                        Inv.Add("Ration", (random.Next(2) + 1));
                    }
                }
            }
            else
            {
                MessageBox.Show("You take an hour to search for food. Unfortunately, you find none.", "Forraging");
            }
        }

        private void btnContineAdventure_Click(object sender, EventArgs e)
        {
            //Test time. If it is past 22:00, camp()
            //If time is not past 22:00
            //Roll for random encounter (Updates with region?)
            //If(RandomEncounter)
            //fight()
            //Else
            //Subtract 2 hours from the time to destination
            //Advance time by 2 hours

            if (time >= 22 || time <= 6)
            {
                camp();
            }
            else
            {
                if (random.Next(10) < 3)
                {
                    fight();
                }
                else
                {
                    timeToDestination -= 2;
                    if (timeToDestination == 0)     //Currently unused
                    {
                        maskLocations(true);
                        currentLocation = nextDestination;
                    }
                }
                passTime(2);
            }
        }

        private void camp()
        {
            //force party to stop and sleep, using 1 ration per adventurer and a random number of firewood between 1 and 5
            MessageBox.Show("With the light fading, the group finds a nice place to set up camp and settle down for the night.", "Camping");
            if (Inv.ContainsKey("Ration"))
            {
                if (Inv["Ration"] > Adventurers.Count)
                    Inv["Ration"] = Inv["Ration"] - Adventurers.Count;
                else if (Inv["Ration"] == Adventurers.Count)
                    Inv.Remove("Ration");
                else
                {
                    MessageBox.Show("You don't have enough rations for the night. Nothing is consumed and everyone takes 4 damage.");
                    foreach (var person in Adventurers.Keys)
                    {
                        Adventurers[person].takeDamage(4);
                    }
                }
            }
            else
            {
                MessageBox.Show("You don't have enough rations for the night. Nothing is consumed and everyone takes 4 damage.");
                foreach (var person in Adventurers.Keys)
                {
                    Adventurers[person].takeDamage(4);
                }
            }

            int woodBurned = random.Next(6) + 1;
            if (Inv.ContainsKey("Firewood"))
            {
                if (Inv["Firewood"] > woodBurned)
                    Inv["Firewood"] = Inv["Firewood"] - woodBurned;
                else if (Inv["Firewood"] == woodBurned)
                    Inv.Remove("Firewood");
            }
            else
            {
                if (Inv.ContainsKey("Firewood"))
                {
                    int coldDamage = woodBurned - Inv["Firewood"];      //Cold damage is equal to the wood required - the wood owned
                    Inv.Remove("Firewood");
                    MessageBox.Show("You don't have enough firewood for the night. Everyone gets cold during the night and takes " + coldDamage + " damage.");
                }
                else
                {
                    MessageBox.Show("You don't have enough firewood for the night. Everyone gets cold during the night and takes " + woodBurned + " damage.");
                }
            }

            checkParty();
            passTime(9);
        }

        private void fight()
        {
            Combat combat = new Combat();
            combat.ShowDialog();
            checkParty();
            passTime(1);
        }

        private void checkParty()
        {
            List<String> toRemove = new List<string>();
            foreach (var member in Adventurers.Keys)
            {
                if (Adventurers[member].Con <= 0)
                {
                    toRemove.Add(member);
                    MessageBox.Show(member + " has died.");
                }
            }

            foreach (string person in toRemove)
            {
                Adventurers.Remove(person);
            }

            if (Adventurers.Count() == 0)
            {
                MessageBox.Show("As your last adventurer passes away, you realize that your adventure has failed.", "Game Over");
                this.Close();
            }
        }

        private void radPlains_CheckedChanged(object sender, EventArgs e)
        {
            /*
            //Test if the location the player is choosing is one they can go to, if it is then set the time to get to destination and hide locations
            if(currentLocation.Equals("Plains") && ActiveControl.Text.Equals("Forest"))
            {
                nextDestination = ActiveControl.Text;
                timeToDestination = 20;
                maskLocations(false);
            }
            else
            {
                MessageBox.Show("You must choose a destination in reach", "Error");
            } */
        }   

        private void maskLocations(Boolean x)
        {
            radPlains.Visible = x;
            radForest.Visible = x;
            radSwamp.Visible = x;
            radMountains.Visible = x;
            radFlameFields.Visible = x;
            radFinish.Visible = x;
        }   //Hides all location radial buttons
    }
}
