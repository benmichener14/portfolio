﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace AdventureGame
{
    public partial class ChooseParty : Form
    {
        private List<String> characters = new List<string>();
        public ChooseParty()
        {
            InitializeComponent();
        }

        //Display Greeting Messages
        private void ChooseParty_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome to Adventure Game! In this game, you will be guiding a group of adventurers on a journey from one side of the isle of Kran to the other.", "Welcome");
            MessageBox.Show("The journey is going to be long and dangerous. Before you get going, you are going to need need to select your party and the supplies you will be starting out with.", "Welcome");
            MessageBox.Show("Adventurers cost money to hire, and supplies can be expensive, so be careful to save enough money to buy everything you need! Once you have everything, we can start the journey northwards!", "Welcome");
            txtGold.Text = (Map.gold).ToString();
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (Double.Parse(txtGold.Text) >= 0 && Double.Parse(txtGold.Text) < 1000)         //If gold is above 0, move on to next form
            {
                ChooseGear GearSelect = new AdventureGame.ChooseGear();
                Map.gold = Double.Parse(txtGold.Text);
                addAdventurers();
                this.Hide();
                GearSelect.ShowDialog();
                this.Close();
            }
            else                                        //Otherwise, don't.
            {
                if (Double.Parse(txtGold.Text) < 0)
                    MessageBox.Show("You have hired too many adventurers and are now in debt! Get rid of some of them!", "Error");
                if (Double.Parse(txtGold.Text) == 1000)
                    MessageBox.Show("You need to hire at least one adventuere.", "Error");
            }
        }

        private void addAdventurers()   //Adds chosen adventurers to master list of Adventurers and their stats
        {
            foreach(String hero in characters)
            {
                StreamReader sr = new StreamReader(hero + ".txt");
                sr.ReadLine();        //Skip Summary
                String name = sr.ReadLine();
                double con = Double.Parse(sr.ReadLine());
                double dex = Double.Parse(sr.ReadLine());
                double skill = Double.Parse(sr.ReadLine());
                double str = Double.Parse(sr.ReadLine());
                sr.Close();

                Map.Adventurers.Add(name, new Stats(name, con, dex, skill, str, 1));

            }
        }

        //Due to the way the form was set up, ActiveControl was not usable in for the information needed from the rad buttons
        private void cbFighterOne_CheckedChanged(object sender, EventArgs e)        //When Check is changed
        {
            if (cbFighterOne.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtFighterOneCost.Text)).ToString();
                characters.Add(txtFighterOneName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtFighterOneCost.Text)).ToString();
                characters.Remove(txtFighterOneName.Text);
            }
        }

        private void cbFighterTwo_CheckedChanged(object sender, EventArgs e)
        {
            if (cbFighterTwo.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtFighterTwoCost.Text)).ToString();
                characters.Add(txtFighterTwoName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtFighterTwoCost.Text)).ToString();
                characters.Remove(txtFighterTwoName.Text);
            }
        }

        private void cbRanger_CheckedChanged(object sender, EventArgs e)
        {
            if (cbRanger.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtRangerCost.Text)).ToString();
                characters.Add(txtRangerName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtRangerCost.Text)).ToString();
                characters.Remove(txtRangerName.Text);
            }
        }

        private void cbHunter_CheckedChanged(object sender, EventArgs e)
        {
            if (cbHunter.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtHunterCost.Text)).ToString();
                characters.Add(txtHunterName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtHunterCost.Text)).ToString();
                characters.Remove(txtHunterName.Text);
            }
        }

        private void cbSorcerer_CheckedChanged(object sender, EventArgs e)
        {
            if (cbSorcerer.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtSorcererCost.Text)).ToString();
                characters.Add(txtSorcererName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtSorcererCost.Text)).ToString();
                characters.Remove(txtSorcererName.Text);
            }
        }

        private void cbWarlock_CheckedChanged(object sender, EventArgs e)
        {
            if (cbWarlock.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtWarlockCost.Text)).ToString();
                characters.Add(txtWarlockName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtWarlockCost.Text)).ToString();
                characters.Remove(txtWarlockName.Text);
            }
        }

        private void cbCleric_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCleric.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtClericCost.Text)).ToString();
                characters.Add(txtClericName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtClericCost.Text)).ToString();
                characters.Remove(txtClericName.Text);
            }
        }

        private void cbMedic_CheckedChanged(object sender, EventArgs e)
        {
            if (cbMedic.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtMedicCost.Text)).ToString();
                characters.Add(txtMedicName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtMedicCost.Text)).ToString();
                characters.Remove(txtMedicName.Text);
            }
        }

        private void cbGuide_CheckedChanged(object sender, EventArgs e)
        {
            if (cbGuide.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtGuideCost.Text)).ToString();
                characters.Add(txtGuideName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtGuideCost.Text)).ToString();
                characters.Remove(txtGuideName.Text);
            }
        }

        private void cbAdventurer_CheckedChanged(object sender, EventArgs e)
        {
            if (cbAdventurer.Checked == true)                                        //If Checked, subtract gold cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) - Double.Parse(txtAdventurerCost.Text)).ToString();
                characters.Add(txtAdventurerName.Text);
            }
            else                                                                    //If Unchecked, Add Gold Cost
            {
                txtGold.Text = (Double.Parse(txtGold.Text) + Double.Parse(txtAdventurerCost.Text)).ToString();
                characters.Remove(txtAdventurerName.Text);
            }
        }

        //Displays Help
        private void btnHelp_ChooseParty_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the screen where you can choose your adventurers. To select an adventurer that you want to bring along, simply check the box next to their specialization. Remember, however, that two heads is not always better than one. The more adventurers you have, the more supplies you will need to bring along!", "Help");
            MessageBox.Show("If you want to know more about an adventurer, simply double click on their name to read more about them. This can teach you more about the usefulness of each adventurer, and will help you get to know the people you are hiring.", "Help");
            MessageBox.Show("Once you have a party that you are happy with, simply click the \"Accept\" button to move on to the supplies select screen", "Help");
        }

        private void txtFighterOne_DoubleClick(object sender, EventArgs e)      //Handles Displaying of all Character Backgrounds
        {
            StreamReader sr = new StreamReader(ActiveControl.Text + ".txt");
            MessageBox.Show(sr.ReadLine(), ActiveControl.Text);
            sr.Close();
        }
    }
}
