﻿namespace AdventureGame
{
    partial class Combat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCheckParty = new System.Windows.Forms.Button();
            this.btnCheckEnemies = new System.Windows.Forms.Button();
            this.txtCombatLog = new System.Windows.Forms.TextBox();
            this.radAttack = new System.Windows.Forms.RadioButton();
            this.radDefend = new System.Windows.Forms.RadioButton();
            this.radRetreat = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTakeAction = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCheckParty
            // 
            this.btnCheckParty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckParty.Location = new System.Drawing.Point(12, 12);
            this.btnCheckParty.Name = "btnCheckParty";
            this.btnCheckParty.Size = new System.Drawing.Size(124, 36);
            this.btnCheckParty.TabIndex = 2;
            this.btnCheckParty.Text = "Check Party";
            this.btnCheckParty.UseVisualStyleBackColor = true;
            this.btnCheckParty.Click += new System.EventHandler(this.btnCheckParty_Click);
            // 
            // btnCheckEnemies
            // 
            this.btnCheckEnemies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckEnemies.Location = new System.Drawing.Point(12, 54);
            this.btnCheckEnemies.Name = "btnCheckEnemies";
            this.btnCheckEnemies.Size = new System.Drawing.Size(124, 36);
            this.btnCheckEnemies.TabIndex = 3;
            this.btnCheckEnemies.Text = "Check Enemies";
            this.btnCheckEnemies.UseVisualStyleBackColor = true;
            this.btnCheckEnemies.Click += new System.EventHandler(this.btnCheckEnemies_Click);
            // 
            // txtCombatLog
            // 
            this.txtCombatLog.Location = new System.Drawing.Point(163, 32);
            this.txtCombatLog.Multiline = true;
            this.txtCombatLog.Name = "txtCombatLog";
            this.txtCombatLog.ReadOnly = true;
            this.txtCombatLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCombatLog.Size = new System.Drawing.Size(235, 176);
            this.txtCombatLog.TabIndex = 6;
            // 
            // radAttack
            // 
            this.radAttack.AutoSize = true;
            this.radAttack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAttack.Location = new System.Drawing.Point(21, 137);
            this.radAttack.Name = "radAttack";
            this.radAttack.Size = new System.Drawing.Size(63, 20);
            this.radAttack.TabIndex = 7;
            this.radAttack.TabStop = true;
            this.radAttack.Text = "Attack";
            this.radAttack.UseVisualStyleBackColor = true;
            // 
            // radDefend
            // 
            this.radDefend.AutoSize = true;
            this.radDefend.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radDefend.Location = new System.Drawing.Point(21, 160);
            this.radDefend.Name = "radDefend";
            this.radDefend.Size = new System.Drawing.Size(70, 20);
            this.radDefend.TabIndex = 8;
            this.radDefend.TabStop = true;
            this.radDefend.Text = "Defend";
            this.radDefend.UseVisualStyleBackColor = true;
            // 
            // radRetreat
            // 
            this.radRetreat.AutoSize = true;
            this.radRetreat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radRetreat.Location = new System.Drawing.Point(21, 183);
            this.radRetreat.Name = "radRetreat";
            this.radRetreat.Size = new System.Drawing.Size(70, 20);
            this.radRetreat.TabIndex = 9;
            this.radRetreat.TabStop = true;
            this.radRetreat.Text = "Retreat";
            this.radRetreat.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(227, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Combat Log";
            // 
            // btnTakeAction
            // 
            this.btnTakeAction.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTakeAction.Location = new System.Drawing.Point(12, 96);
            this.btnTakeAction.Name = "btnTakeAction";
            this.btnTakeAction.Size = new System.Drawing.Size(124, 36);
            this.btnTakeAction.TabIndex = 11;
            this.btnTakeAction.Text = "Take Action";
            this.btnTakeAction.UseVisualStyleBackColor = true;
            this.btnTakeAction.Click += new System.EventHandler(this.btnTakeAction_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelp.Location = new System.Drawing.Point(371, 3);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(27, 23);
            this.btnHelp.TabIndex = 12;
            this.btnHelp.Text = "?";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // Combat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 220);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.btnTakeAction);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radRetreat);
            this.Controls.Add(this.radDefend);
            this.Controls.Add(this.radAttack);
            this.Controls.Add(this.txtCombatLog);
            this.Controls.Add(this.btnCheckEnemies);
            this.Controls.Add(this.btnCheckParty);
            this.Name = "Combat";
            this.Text = "Combat";
            this.Load += new System.EventHandler(this.Combat_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCheckParty;
        private System.Windows.Forms.Button btnCheckEnemies;
        private System.Windows.Forms.TextBox txtCombatLog;
        private System.Windows.Forms.RadioButton radAttack;
        private System.Windows.Forms.RadioButton radDefend;
        private System.Windows.Forms.RadioButton radRetreat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTakeAction;
        private System.Windows.Forms.Button btnHelp;
    }
}